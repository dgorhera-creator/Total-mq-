// Builds the offline "www" folder: copies libraries locally, builds Tailwind CSS,
// and rewrites the CDN links in src/index.html to local files.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const root = path.join(__dirname, '..');
const nm = (...p) => path.join(root, 'node_modules', ...p);
const www = path.join(root, 'www');
const libs = path.join(www, 'libs');

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(libs, 'fa', 'css'), { recursive: true });

// 1) Copy JS libraries
fs.copyFileSync(nm('jspdf', 'dist', 'jspdf.umd.min.js'), path.join(libs, 'jspdf.umd.min.js'));
fs.copyFileSync(nm('html2canvas', 'dist', 'html2canvas.min.js'), path.join(libs, 'html2canvas.min.js'));
fs.copyFileSync(nm('xlsx', 'dist', 'xlsx.full.min.js'), path.join(libs, 'xlsx.full.min.js'));

// 2) FontAwesome (css + fonts)
fs.copyFileSync(nm('@fortawesome', 'fontawesome-free', 'css', 'all.min.css'), path.join(libs, 'fa', 'css', 'all.min.css'));
fs.cpSync(nm('@fortawesome', 'fontawesome-free', 'webfonts'), path.join(libs, 'fa', 'webfonts'), { recursive: true });

// 3) Tailwind CSS (built from the classes used in index.html)
execSync(
  `npx tailwindcss -i "${path.join(root, 'tw-input.css')}" -o "${path.join(libs, 'tailwind.css')}" --content "${path.join(root, 'src', 'index.html')}" --minify`,
  { stdio: 'inherit', cwd: root }
);

// 4) Rewrite CDN links -> local files
let html = fs.readFileSync(path.join(root, 'src', 'index.html'), 'utf8');
const swaps = [
  [/<script src="https:\/\/cdn\.tailwindcss\.com"><\/script>/, '<link rel="stylesheet" href="libs/tailwind.css">'],
  [/https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/xlsx\/[^"]+/, 'libs/xlsx.full.min.js'],
  [/https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/html2canvas\/[^"]+/, 'libs/html2canvas.min.js'],
  [/https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jspdf\/[^"]+/, 'libs/jspdf.umd.min.js'],
  [/https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/font-awesome\/[^"]+/, 'libs/fa/css/all.min.css']
];
for (const [re, to] of swaps) {
  if (!re.test(html)) { console.error('WARNING: link not found for', re); continue; }
  html = html.replace(re, to);
}
// Tailwind CDN config block (if any) is not needed offline
fs.writeFileSync(path.join(www, 'index.html'), html);

const left = (html.match(/https?:\/\/[^"')\s]+/g) || []).filter(u => /cdn|gstatic|googleapis/.test(u));
console.log(left.length ? 'Still external: ' + left.join(', ') : 'OK: www/ is fully offline.');
