# RMC Dispatch - APK Project (Offline, No Firebase / No API)

Data sirf phone me save hota hai (localStorage). Har save par 2 copy banti hain (main + safety copy).
Header me **Backup** (JSON file) aur **Restore** (sirf missing entries add karta hai, kuch delete nahi karta) buttons hain.
Android app me PDF / Excel / Backup file "Share" sheet se save hoti hai (Drive, WhatsApp, Files).

## Ek baar ki taiyari (PC par)
1. Node.js (LTS) install karo: https://nodejs.org
2. Android Studio install karo (ye Android SDK + Java saath laata hai): https://developer.android.com/studio

## APK banane ke steps (is folder me terminal kholo)
```
npm install
npm run build:www
npx cap add android
npx cap sync android
npx cap open android
```
Android Studio khulne par: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
APK yaha milegi: `android/app/build/outputs/apk/debug/app-debug.apk`

Phone me APK copy karke install karo ("Unknown sources" allow karna padega).

## Baad me HTML badalni ho to
`src/index.html` me badlav karo, phir:
```
npm run sync
```
aur Android Studio se dobara APK build karo.

## Zaroori baatein
- Password abhi bhi `admin1235` hai (src/index.html me `handleLogin`).
- App ka data **uninstall karne ya "Clear data" karne par** delete ho jata hai. Isliye time-time par **Backup** lo.
- Android me `Print` button kaam nahi karta; PDF button use karo.
- Release/Play Store ke liye signed APK/AAB alag se banana padta hai (Android Studio: Build > Generate Signed Bundle / APK).
